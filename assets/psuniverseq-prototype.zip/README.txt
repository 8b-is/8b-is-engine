PSU NIVERSEQ — the chaos overworld

Playable prototype (single-file HTML, no install):
- psuniverseq.html — the full game: lore, 4 deity bosses, the ZEN mechanic
- sanctuary-floor.html — the first demo: stomp, split, bounce

Open either file in any modern browser (Chrome/Firefox/Safari).
Controls: wasd move · space jump · stomp · T talents · N rename · s say · r reset
